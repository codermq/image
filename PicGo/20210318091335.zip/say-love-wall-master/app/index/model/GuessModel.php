<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/16
 * Time: 21:01
 */

namespace app\index\model;

use think\Model;
use app\index\model\LikeModel;
class GuessModel extends Model
{
    protected $table = 'gk_guess';
}