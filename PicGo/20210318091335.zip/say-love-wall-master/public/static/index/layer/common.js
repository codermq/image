/**
 * Created by admin on 2018/9/24.
 * 主要处理layer事件
 */













